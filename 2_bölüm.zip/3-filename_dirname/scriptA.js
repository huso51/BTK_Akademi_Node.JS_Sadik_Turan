
console.log(__filename);
console.log(__dirname);

var firstName = 'Sadık';
var log = function (name) {
    console.log(name);
}

exports = {
    firstName,
    log
}

