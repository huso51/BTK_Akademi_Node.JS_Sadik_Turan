const scriptA = require('./scriptA');

scriptA.log('Çınar');
console.log(scriptA.name);
// console.log(scriptA.age);