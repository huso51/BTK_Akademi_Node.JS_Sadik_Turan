// tarayıcı



// console.log(lastName);
// console.log(firstName);
// console.log(window);

// window.console.log()
// window.setInterval
// window.setTimeout
// window.clearTimeout

// nodejs

// global

// var lastName = 'Turan';
// console.log(global.lastName);
// global.setTimeout(() => {},);
console.log(global);
