var firstName = 'Sadık';

